package demo;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="EmpTable")
public class Emp implements Serializable {
	@Id
	@Column(length=5)
	@Length(max=5,message="Fname must be < 5")
	private String fname;
	@Id
	@Column(length=5)
	private String lname;
	
	@Column(name="bday")
	private Date birthday;
	@Column(name="salary")
	@Min(value=100, message=" min validation ...")
	@Max(value=1000, message=" max validation" )
	private double salary;
	
	@Column(name="projid")
	private String projid;
	@Email(message="email validation")
	@Column(name="emailid")
	private String email;
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getProjid() {
		return projid;
	}
	public void setProjid(String projid) {
		this.projid = projid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Emp [fname=" + fname + ", lname=" + lname + ", birthday="
				+ birthday + ", salary=" + salary + ", projid=" + projid
				+ ", email=" + email + "]";
	}

	
	
	
}


