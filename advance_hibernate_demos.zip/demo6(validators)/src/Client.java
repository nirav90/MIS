import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import util.HibernateUtil;
import demo.Emp;


public class Client {
	private static SessionFactory sf = HibernateUtil.getSessionFactory();
	
	public static boolean validate(Emp e)
	{
		ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
		Validator validator = vf.getValidator();
		Set<ConstraintViolation<Emp>> setcon = validator.validate(e);
		System.out.println(setcon);
		if(setcon.size() >0)
		{
			System.out.println("Messages  : ");
			for (ConstraintViolation<Emp> cv : setcon) {
				System.out.println(cv.getMessage());
			}
			return false;
		}
		else
		{
			System.out.println("Valid Object.....");
			return true;
		}
	}
	public static  void create(Emp emp){
		Session session=null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			if (validate(emp))
				session.save(emp);
			tx.commit();
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
			tx.rollback();
		}finally{
			session.close();
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp e= new Emp();
		
		e.setFname("vais");
		e.setLname("tapa");
		e.setEmail("aaa@aaa");
		e.setSalary(500);
		create(e);
		HibernateUtil.getSessionFactory().close();
	}

}
