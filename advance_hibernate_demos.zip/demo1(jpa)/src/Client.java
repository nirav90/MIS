import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import demo.Dept;
import demo.DeptDAO;


public class Client {

	public static void main(String[] args) {
		DeptDAO dao = new DeptDAO();
		Dept d = new Dept();
		d.setDeptno(20);
		d.setDname("Fin" );
		d.setLoc("Pune" );

		dao.create(d);

		List<Dept> list = dao.list();
		for (Dept dept : list) {	
			System.out.println(dept);
		}
		
	}

}
