package demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DeptDAO {
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("myunit");
	public void create(Dept d){
		EntityManager em=null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			em.persist(d);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println(" Exception :  " + e);
		}finally{
			em.close();
		}
	}
	
	public List<Dept> list(){
		EntityManager em=null;
		EntityTransaction tx = null;
		List<Dept> list= null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			Query query =  em.createQuery("select d from Dept  d");
			list = query.getResultList();
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println(" Exception :  " + e);
		}finally{
			em.close();
		}
	return list;
		
	}
	 public void update(Dept newdept){} 
	public void delete(int deptno){
		
	}
}
