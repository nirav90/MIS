package demo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import util.HibernateUtil;


public class DeptDAO {
	private static SessionFactory emf = HibernateUtil.getSessionFactory();
	public void create(Dept d){
		Session session=null;
		Transaction tx = null;
		try {
			session = emf.openSession();
			tx = session.beginTransaction();
			session.save(d);
			tx.commit();
			
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
			tx.rollback();
		}finally{
			session.close();
		}
	}
	
	public void list(String s){
		Session session=null;
		try {
			session = emf.openSession();
		//	Query query =  session.createQuery("select d from Dept d");
			Query query = session.getNamedQuery("listbycity" );
			query.setString("locvar", s );
			List<Dept> list = query.list();
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	public void crit(String s){
		Session session=null;
		try {
			session = emf.openSession();
			Criteria crit = session.createCriteria(Dept.class);
			crit.add(Restrictions.eq("loc" ,s));
			
			List<Dept> list = crit.list();
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	
	
	 public void update(Dept newdept){} 
	public void delete(int deptno){
		
	}
}
