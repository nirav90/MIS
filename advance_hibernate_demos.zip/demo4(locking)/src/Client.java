import org.hibernate.LockOptions;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.stat.QueryStatistics;
import org.hibernate.stat.Statistics;

import util.HibernateUtil;
import demo.Dept;
import demo.DeptDAO;


class Helper extends Thread
{
	private String loc;
	public Helper(String loc)
	{
		this.loc = loc;
	}
@Override
public void run() {
	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session session=null;
	Transaction tx = null;
	try {
		session = sf.openSession();
		tx = session.beginTransaction();
		
		Dept d = (Dept)session.get(Dept.class,10);
		System.out.println( "original Dept record = " + d);
		d.setLoc(loc);
		System.out.println("current modified Record " + d);
		Thread.sleep(5000);
		tx.commit();
		
	} catch (Exception e) {
		System.out.println(" Exception :  " + e);
		tx.rollback();
	}finally{
		session.close();
	}
}	

}
public class Client {
	static SessionFactory sf = HibernateUtil.getSessionFactory();
public static void printstats()
{
	Statistics stats = sf.getStatistics();
	String[] queries = stats.getQueries();
	System.out.println("Total Number of queries = " + queries.length);
	for(int i = 0; i< queries.length; i++)
	{
		QueryStatistics qs =  stats.getQueryStatistics(queries[i]);
		System.out.println(" \n" +  queries[i]   + " \n " + qs.getExecutionCount() + qs.getExecutionAvgTime() );
	}
}
	
	public static void main(String[] args) {
		Helper h = new Helper("Blr");
		Helper h1 = new Helper("Pune");
		
		h.start();
		h1.start();
		
		// TODO Auto-generated method stub
		DeptDAO dao = new DeptDAO();
	/*	for(int i = 10; i<= 100; i+=10)
		{
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Dnameof" + i );
			if ((i % 20)==0)
				d.setLoc("Pune" );
			else
				d.setLoc("Hyd");
			dao.create(d);
		}
		*/
		for(int i = 10; i< 100; i+=1)
		{
			if ((i % 20)==0)
				dao.list("Pune" );
			else
				dao.list("Hyd");
		}
		printstats();
		for(int i = 10; i< 100; i+=1)
		{
			if ((i % 20)==0)
				dao.crit("Pune" );
			else
				dao.crit("Hyd");
		}
		printstats();
//		HibernateUtil.getSessionFactory().close();
	}

}
