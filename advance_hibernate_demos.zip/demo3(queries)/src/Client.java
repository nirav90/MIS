import java.util.List;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;

import util.HibernateUtil;
import demo.Dept;
import demo.Emp;

public class Client {
static SessionFactory sf  = HibernateUtil.getSessionFactory();
public static void deptempcount()
{
	StatelessSession session=null;
	try {
		session = sf.openStatelessSession();
		Query q = session.createQuery(
		//		"select e.department.deptno, count(e) from Emp e  group by e.department.deptno");
				"select d.deptno,count(e) from Dept as d left  join  d.emps as  e  group by d.deptno ");
		ScrollableResults rs = q.scroll();
		while(rs.next())
		{
			System.out.println( rs.get(0) +  "\t\t" + rs.get(1));
		}
		/*List<Dept> list = q.list();
		for (Dept dept : list) {
			System.out.println(dept + "\t\t"+ dept.getEmps().size());
		}
		*/
	} catch (Exception e) {
		System.out.println(" Exception :  " + e);
	}finally{
		session.close();
	}
	
}
public static void list()
{
	Session session=null;
	try {
		session = sf.openSession();
/*		Query q = session.createQuery("select d from Dept d");
		List<Dept> list = q.list();
		for (Dept dept : list) {
			System.out.println(dept );
			System.out.println("\t\t"+ dept.getEmps());
		}
*/
/*		Query q = session.createQuery("select e from Emp e");
		List<Emp> list = q.list();
		for (Emp e : list) {
			System.out.println(e );
			System.out.println("\t\t"+ e.getDepartment());
		}
*/
		Query q = session.createQuery("select d from Dept d");
		List<Dept> list = q.list();
		Query q1 = session.createQuery("select e from Emp e");
		List<Emp> list1 = q1.list();
		
		for (Emp e : list1) {
			System.out.println(e );
			System.out.println("\t\t"+ e.getDepartment());
		}
		
	} catch (Exception e) {
		System.out.println(" Exception :  " + e);
	}finally{
		session.close();
	}
	
}

public static  void create(){
	Session session=null;
	Transaction tx = null;
	try {
		session = sf.openSession();
		tx = session.beginTransaction();
		Dept d1 = new Dept(30, "IT", "Hyd");
		
		Dept d = new Dept(40, "HR", "Pune");
		Emp e = new Emp(106,"FFFF",6000);
		
	//	d.getEmps().add(e);
	//	d.getEmps().add(e2);
		
		e.setDepartment(d);
		session.save(d);
		session.save(e);
		session.save(d1);
		
		
		tx.commit();
		
	} catch (Exception e) {
		System.out.println(" Exception :  " + e);
		tx.rollback();
	}finally{
		session.close();
	}
}


	public static void main(String[] args) {
		//create();
		//list();
		deptempcount();
		HibernateUtil.getSessionFactory().close();
	}

}
