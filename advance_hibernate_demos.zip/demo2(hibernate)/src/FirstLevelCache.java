import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import util.HibernateUtil;
import demo.Dept;


public class FirstLevelCache {
	static SessionFactory sf = HibernateUtil.getSessionFactory();
	public static  void m1(){
		Session session=null;
		try {
			session = sf.openSession();
			
			Dept d =(Dept) session.get(Dept.class, 10);
			System.out.println( "after get "+ d);
			Dept d1 =(Dept) session.load(Dept.class, 10);
			System.out.println( "after load "+ d);
			Query query  = session.createQuery("select d from Dept d where d.deptno= 10");
			Dept d2 = (Dept)query.list().get(0);
			System.out.println("after query " + d2);
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	
	public static  void m2(){
		Session session=null;
		try {
			session = sf.openSession();
			
			Dept d1 =(Dept) session.load(Dept.class, 10);
			System.out.println( "after load "+ d1);
			Dept d =(Dept) session.get(Dept.class, 10);
			System.out.println( "after get "+ d);
		
			Query query  = session.createQuery("select d from Dept d where d.deptno= 10");
			Dept d2 = (Dept)query.list().get(0);
			System.out.println("after query " + d2);
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	public static  void m3(){
		Session session=null;
		try {
			session = sf.openSession();
			Query query  = session.createQuery("select d from Dept d where d.deptno= 10");
			Dept d2 = (Dept)query.list().get(0);
			System.out.println("after query " + d2);
			
			Dept d1 =(Dept) session.load(Dept.class, 10);
			System.out.println( "after load "+ d1);
			Dept d =(Dept) session.get(Dept.class, 30);
			System.out.println( "after get "+ d);
		
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}		
	
	public static void main(String[] args) {
	
		m3();
	}

}
