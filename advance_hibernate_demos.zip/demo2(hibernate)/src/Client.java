import util.HibernateUtil;
import demo.Dept;
import demo.DeptDAO;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeptDAO dao = new DeptDAO();
		for(int i = 10; i<= 100; i+=10)
		{
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Dnameof" + i );
			if ((i % 20)==0)
				d.setLoc("Pune" );
			else
				d.setLoc("Hyd");
			dao.create(d);
		}
		dao.list();
		HibernateUtil.getSessionFactory().close();
	}

}
