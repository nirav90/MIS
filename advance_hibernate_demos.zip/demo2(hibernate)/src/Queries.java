import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import util.HibernateUtil;
import demo.Dept;


public class Queries {
	static SessionFactory sf = HibernateUtil.getSessionFactory();
	public static  void query1(){
		Session session=null;
		try {
			session = sf.openSession();
		//Option 1 
		/*	Criteria query = session.createCriteria(Dept.class);
			query.add(Restrictions.eq("loc" ,"Hyd"));
		*/
		// Option 2 
			Query query  = session.createQuery("select d from Dept d where d.loc=:locvar");
			query.setString("locvar", "Hyd");
			List<Dept> list = query.list();
			for (Dept dept : list) {
				System.out.println(dept);
			}
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	
	public static  void query2(){
		Session session=null;
		try {
			session = sf.openSession();
			Query query  = session.createQuery("select d from Dept d");
			
			query.setFirstResult(0+3+3);
			query.setMaxResults(3);
			List<Dept> list = query.list();
			for (Dept dept : list) {
				System.out.println(dept);
			}
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}

	public static  void query3(){
		Session session=null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx  = session.beginTransaction();
	/*		Query query  = session.createQuery("select d from Dept d where loc='Hyd'");
			List<Dept> list = query.list();
			for (Dept dept : list) {
				dept.setLoc("Hyderabad");
			}
	*/
			Query query = session.createQuery("update Dept set loc='Hyd' where  loc='Hyderabad' ");
			System.out.println("No of records modified =  " +  query.executeUpdate());
			tx.commit();
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	
	
	public static void main(String[] args) {
	
		query3();
	}

}
