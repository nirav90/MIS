import org.hibernate.Cache;
import org.hibernate.stat.QueryStatistics;
import org.hibernate.stat.Statistics;

import util.HibernateUtil;
import demo.Dept;
import demo.DeptDAO;


public class QueryClient {
	static DeptDAO dao = new DeptDAO();
	public static void insert()
	{
		
		for(int i = 10; i<= 50; i+=10)
		{
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Dnameof" + i );
			if ((i % 20)==0)
				d.setLoc("Pune" );
			else
				d.setLoc("Hyd");
			dao.create(d);
		}

	}
	public static void printstats()
	{
		Statistics stats = HibernateUtil.getSessionFactory().getStatistics();
		System.out.println("Put Count = " + stats.getSecondLevelCachePutCount());
		System.out.println("Hit Count = " + stats.getSecondLevelCacheHitCount());
		System.out.println("Miss Count = " + stats.getSecondLevelCacheMissCount());
	}
	public static void clearcache()
	{
		Cache cache = HibernateUtil.getSessionFactory().getCache();
		cache.evictQueryRegion("depthyd");
		// or cache.evictAllRegions();
		System.out.println("Evicting......................");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//insert();
		System.out.println("\n\nInvoking FirstTime");
		dao.list();
		System.out.println("\n\nInvoking SecondTime");
		dao.list();
		printstats();
		clearcache();
		HibernateUtil.getSessionFactory().close();
	}

}
