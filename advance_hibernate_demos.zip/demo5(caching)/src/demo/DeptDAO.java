package demo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import util.HibernateUtil;


public class DeptDAO {
	private static SessionFactory emf = HibernateUtil.getSessionFactory();
	public void create(Dept d){
		Session session=null;
		Transaction tx = null;
		try {
			session = emf.openSession();
			tx = session.beginTransaction();
			session.save(d);
			tx.commit();
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
			tx.rollback();
		}finally{
			session.close();
		}
	}
	
	public void list(){
		Session session=null;
		try {
			session = emf.openSession();
			Query query =  session.createQuery("select d from Dept d where loc =?");
			query.setString(0,"Hyd" );
			query.setCacheable(true);
			query.setCacheRegion("depthyd");
			System.out.println("in List - First Call ");
			List<Dept> list = query.list();
			for (Dept dept : list) {
				System.out.println(dept);
			}
			System.out.println("----------------Second Call ");
			System.out.println("Sleeping ..............................");
			Dept d=  new Dept(70, "AAA", "Hyd");
		//	create(d);
			//Thread.sleep(5000);
			Query query1 =  session.createQuery("select d from Dept d where loc = ?");
			query1.setCacheRegion("deptpune");
			query1.setString(0,"Pune" );
			query1.setCacheable(true);
			List<Dept> list1 = query1.list();
			for (Dept dept : list1) {
				System.out.println(dept);
			}
			
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
		
	}
	 public void update(Dept newdept){} 
	public void delete(int deptno){
		
	}
}
