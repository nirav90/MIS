import java.util.List;

import org.hibernate.Cache;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.stat.QueryStatistics;
import org.hibernate.stat.Statistics;

import util.HibernateUtil;
import demo.Dept;
import demo.DeptDAO;


public class Client {
	static DeptDAO dao = new DeptDAO();
	public static void printstats()
	{
		Statistics stats = HibernateUtil.getSessionFactory().getStatistics();
		System.out.println("Put Count = " + stats.getSecondLevelCachePutCount());
		System.out.println("Hit Count = " + stats.getSecondLevelCacheHitCount());
		System.out.println("Miss Count = " + stats.getSecondLevelCacheMissCount());
	}
	public static void list(){
		Session session=null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			Query query =  session.createQuery("select d from Dept d");
			query.setCacheable(true);
			System.out.println("in List - First Call ");
			List<Dept> list = query.list();
			for (Dept dept : list) {
				System.out.println(dept);
			}
			Dept d= (Dept) session.get(Dept.class,80);
			System.out.println("after Get request =" + d);
			
			Dept d1= (Dept) session.load(Dept.class,80);
			System.out.println("after Load  request =" + d1);
			
			
		} catch (Exception e) {
			System.out.println(" Exception :  " + e);
		}finally{
			session.close();
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//insert();
		System.out.println("\n\nInvoking FirstTime");
		list();
		System.out.println("\n\nInvoking SecondTime");
		list();
		printstats();

		HibernateUtil.getSessionFactory().close();
	}

}
