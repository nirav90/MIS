package demo;

import java.util.HashSet;
import java.util.Set;

public class Dept {
	
	private Set<Emp> emps = new HashSet<Emp>(); 
	
	public Dept()
	{
		System.out.println("Dept Constructor");
	}
	private int deptno;
	private String dname;
	private String loc;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public Set<Emp> getEmps() {
		
		return emps;
	}
	public void setEmps(Set<Emp> emps) {
		
		this.emps = emps;
	}
	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", loc=" + loc
				+ "]";
	}
	

}
