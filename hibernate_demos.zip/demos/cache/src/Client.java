import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import demo.Dept;
import demo.Emp;

import util.HibernateUtil;



public class Client {
	static SessionFactory sf = HibernateUtil.getSessionFactory();
	public static void insert()
	{
		
		Session session = null;
		Transaction tr = null;
		try{
				session = sf.openSession();
				tr = session.beginTransaction();
				Dept d = new Dept();
				d.setDeptno(20);
				d.setDname("Fin");
				d.setLoc("Pune");
				
				Emp e = new Emp();
				e.setEname("ccc"); e.setSalary(3000);
				
				Emp e1 = new Emp();
				e1.setEname("ddd"); e1.setSalary(4000);
				
		/*		session.save(e);
				session.save(e1);
			*/	
				d.getEmps().add(e);
				d.getEmps().add(e1);
				
				session.save(d);
				
						
				tr.commit();
				session.close();
				
		}catch (Exception e) {
			System.out.println("in Insert Catch..Rollingback  : \n"+ e.getMessage());
			tr.rollback();
		}
		finally{
			System.out.println("Closing session ....");
			//session.close();
			
		}
	}
	public static void main(String[] args) {
		list();
		list();
	}

	public static void list()
	{
		Session session = sf.openSession();
		Query q = session.createQuery("from Dept");
		q.setCacheable(true);
		List<Dept>  list = q.list();
		for (Dept dept : list) {
			System.out.println(dept);
		}
	

	}
}
